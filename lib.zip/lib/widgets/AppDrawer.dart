import 'package:bhagyoday/screen/About_Us.dart';
import 'package:bhagyoday/screen/Privacy_Policy.dart';
import 'package:bhagyoday/screen/Terms_Condition.dart';
import 'package:bhagyoday/screen/advertise_screen.dart';
import 'package:bhagyoday/screen/all_events.dart';

import 'package:bhagyoday/screen/faq_screen.dart';
import 'package:bhagyoday/screen/home_screen.dart';
import 'package:bhagyoday/screen/horoscope.dart';
import 'package:bhagyoday/screen/indian_festival.dart';
import 'package:bhagyoday/screen/indian_holidays.dart';
import 'package:bhagyoday/screen/logout.dart';
import 'package:bhagyoday/screen/next_yr_events.dart';
import 'package:bhagyoday/screen/panchang.dart';
import 'package:bhagyoday/screen/vivha.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:shared_preferences/shared_preferences.dart';

class AppDrawer extends StatefulWidget {
  //final String email;
  @override
  static const Color midnightBlue = const Color.fromRGBO(227, 30, 36, 1);

  @override
  _AppDrawerState createState() => _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {
  var username;
//var userid;
  var id;
  getStringValuesSF() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String useridValue = prefs.getString('userid');
    print(useridValue);
    //return useridValue;
    setState(() {
      username = prefs.getString("email");
      id = prefs.getString('userid');
    });
  }

  getStringValues() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String useridValue = prefs.getString('id');
    print(useridValue);
    //return useridValue;
    setState(() {
      // username = prefs.getString("email");
      id = prefs.getString('id');
    });
  }

  @override
  void initState() {
    super.initState();
    getStringValuesSF();
    getStringValues();
  }

  Widget build(BuildContext context) {
    // TODO: implement build

    return Drawer(
        child: ListView(
      children: <Widget>[
        UserAccountsDrawerHeader(
          decoration: BoxDecoration(color: AppDrawer.midnightBlue),
          accountName: Text(
            '${username}',
            style:
                TextStyle(fontSize: 15.0, color: Colors.white.withOpacity(1.0)),
          ),
          currentAccountPicture: CircleAvatar(
            backgroundColor: Theme.of(context).platform == TargetPlatform.iOS
                ? new Color(0xFF0062ac)
                : Colors.white,
            child: Icon(
              Icons.person,
              size: 50,
            ),
          ),
        ),
        //  DrawerHeader(

        //   child: Container(
        //     child: Text('${email}', style: TextStyle(color: Colors.white.withOpacity(1.0)),),
        //     alignment: Alignment.bottomLeft, // <-- ALIGNMENT
        //    height: 10,
        //    ),
        //  decoration: BoxDecoration(
        //       color: midnightBlue
        //   ),
        //   ),
        Divider(),
        ListTile(
          leading: new Image.asset("assets/Drawer/allcategories.png",
              width: 20.0, color: AppDrawer.midnightBlue),
          title: Text('Home',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => HomeScreen()));
          },
        ),


        ListTile(
          leading: new  Icon(Icons.favorite,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('Vivha',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Vivha()));
          },
        ),
        ListTile(
          leading: new  Icon(Icons.amp_stories,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('Horoscope',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Horoscope()));
          },
        ),
        ListTile(
          leading: new  Icon(Icons.adjust,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('Panchang',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Panchang()));
          },
        ),
        Divider(color: AppDrawer.midnightBlue),

        ListTile(
          leading: new  Icon(Icons.event,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('All Events',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => All_Events()));
          },
        ),

        ListTile(
          leading: new  Icon(Icons.airport_shuttle,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('Indian Holidays',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Ind_Holidays()));
          },
        ),
        ListTile(
          leading: new  Icon(Icons.festival,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('Indian Festivals',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Ind_Festivals()));
          },
        ),

        ListTile(
          leading: new  Icon(Icons.next_week,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('Next Year Events',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Next_yr_events()));
          },
        ),
        Divider(color: AppDrawer.midnightBlue),

        ListTile(
          leading: new Image.asset("assets/Drawer/aboutus.png",
              width: 20.0, color: AppDrawer.midnightBlue),
          title: Text('About Us',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => About_Us_Screen()));
          },
        ),

        ListTile(
          leading: new Image.asset("assets/Drawer/contactus.png",
              width: 20.0, color: AppDrawer.midnightBlue),
          title: Text('Contact Us',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
          },
        ),

        Divider(color: AppDrawer.midnightBlue),
        ListTile(
          leading: new Image.asset("assets/Drawer/advertise.png",
              width: 20.0, color: AppDrawer.midnightBlue),
          title: Text('Advertise',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Advertise_Screen()));
          },
        ),
        ListTile(
          leading: new  Icon(Icons.rate_review,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('Rate App',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {


          },
        ),
        ListTile(
          leading: new  Icon(Icons.share,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('Share App',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {

          },
        ),
        ListTile(
          leading: new  Icon(Icons.line_style,
              size: 25.0, color: AppDrawer.midnightBlue),
          title: Text('FAQ',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => faq()));
          },
        ),
        ListTile(
          leading: new Image.asset("assets/Drawer/terms.png",
              width: 20.0, color: AppDrawer.midnightBlue),
          title: Text('Terms & Condition',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => TermsScreen()));
          },
        ),

        ListTile(
          leading: new Image.asset("assets/Drawer/privacy.png",
              width: 20.0, color: AppDrawer.midnightBlue),
          title: Text('Privacy Policy',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => PolicyScreen()));
          },
        ),



        Divider(color: AppDrawer.midnightBlue),
        ListTile(
          leading: new Image.asset("assets/Drawer/logout.png",
              width: 20.0, color: AppDrawer.midnightBlue),
          title: Text('Log Out',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
          onTap: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => logout()));
          },
        ),
      ],
    ));
  }
}
